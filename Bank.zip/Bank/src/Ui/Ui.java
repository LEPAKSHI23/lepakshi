package Ui;

import java.util.Scanner;

import Bank.Customer;
import Ser.ImpSer;


public class Ui {
	public static void main(String[] args) 
	{

	ImpSer ser= new ImpSer();

	while (true) {
		
	int a=0;
	long accnum;
	String pwd;
	

		System.out.println("welcome to bank management system");
		System.out.println("1. add customer");
		System.out.println("2. show balance");
		System.out.println("3. withdraw");
		System.out.println("4. deposit ");
		System.out.println("5. fund transfer");
		System.out.println("6.print transaction");
		System.out.println("7. exit");

		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		Customer bean = new Customer();
		switch (choice)
		{
	    
		case 1:
			do{
			System.out.println("enter customer name \n");
			String cname = sc.next();
		
			if(ser.name(cname))
			{bean.setCname(cname);
				++a;}
			else
			
			{
				System.err.println("Invalid...");
				System.out.println("enter the correct value\n");
			}
			}while(a!=1);
			
			
			do
			{
			System.out.println("enter pan number...\n");
			String pan_num = sc.next();

			
			if(ser.pan(pan_num))
			{
				bean.setPan_num(pan_num);
				++a;}
			else
			{
				System.err.println("Invalid...\n");
			System.out.println("enter the  valied pan number  \n");
			}
			
			
		}while(a!=2);
			
			do
			{
			System.out.println("enter date of birth\n");
			String dob= sc.next();
			
			if(ser.dob(dob))
			{
				bean.setDob(dob);
				++a;
			}
			else
			{
				System.err.println("Invalid...");
				System.out.println("enter the  date of birth in dd/mm/yyyy formate...\n");
			}
			}while(a!=3);
			

			do
			{
			System.out.println("enter phone number\n");
			String phnum = sc.next();
			
			
			if(ser.phnum(phnum))
			{
				bean.setPhnum(phnum);
				++a;
			}
			else
			{
				System.err.println("Invalid...");
			
				System.out.println("enter the valide phone number \n");
			}
			}while(a!=4);
			
			do
			{
			System.out.println("enter adhar number..without space....\n");
			String adhar = sc.next();
			
			if(ser.adhar(adhar))
			{			
				bean.setAdhar(adhar);
				++a;
			}
			else
			{
				System.err.println("Invalid...");
				System.out.println(" enter the correct adhar number \n");
			}
			}while(a!=5);
			
			do{
			System.out.println("enter the 4 digit password you want");
			
			
			pwd =sc.next();
			if(ser.valpwd(pwd))
			{
				bean.setPwd(pwd);
				++a;
				System.out.println("password set sucessfully \n");
			}
			else 
			System.err.println("password didnot fulfil the condition..\n");
		
			}while (a!=6);
			
			
			if (a==6) {
				
				bean.setBal(0);
				System.out.println("your account number is \n"+ser.addCustomer(bean));
			
				
					System.out.println("account created  successfully...\n");
					
				
				}
			break;

		case 2:
			do{
			System.out.println("enter your account number\n");
			 accnum=sc.nextLong();
			
			if(ser.valac(accnum)==false)
				System.err.println( "enter the correct account number\n");
			}while(ser.valac(accnum)==false);
			
			do{
			System.out.println("enter you password.. \n");
			pwd=sc.next();
			
			if(ser.valpwd(pwd)==false)
				System.err.println( "enter the correct password..\n");
			}while(ser.valpwd(pwd)==false);
			
		
			if(ser.chk(accnum ,pwd))
			
			 {
				System.out.println("your balance is"+ser.showBal(accnum));
			}
			
			else
				System.out.println(" password you hav typied is not matched with the account number\n");
	
			break;
		case 3:
			
			do{
				System.out.println("enter your account number\n");
				 accnum=sc.nextLong();
				
				if(ser.valac(accnum)==false)
					System.err.println( "enter the correct account number\n");
				}while(ser.valac(accnum)==false);
				
				do{
				System.out.println("enter you password.. \n");
				pwd=sc.next();
				
				if(ser.valpwd(pwd)==false)
					System.err.println( "enter the correct password..\n");
				}while(ser.valpwd(pwd)==false);
			
			if(ser.chk(accnum ,pwd))
			{
			System.out.println("your balance is"+ser.showBal(accnum));
			System.out.println("enter the withdrawal amount..\n");
			double amt=sc.nextDouble();
			
			if(ser.minBal(accnum))
			{
			if(amt<(ser.showBal(accnum)-1500))
			{
				System.out.println(" your balance is"+ser.withdraw( accnum,amt)+"\n withdrawn successfully ...\n");
			}
			else 
				System.out.println("exicted your minimam balance value...\n");
			}
			else 
				System.out.println("your balance is low..\n");
			}
			else
				System.out.println(" password you hav typied is not matched with the account number\n");
		
			break;
			
		case 4:
			
			do{
				System.out.println("enter your account number \n");
				 accnum=sc.nextLong();
				
				if(ser.valac(accnum)==false)
					System.err.println( "enter the correct account number");
				}while(ser.valac(accnum)==false);
				
				do{
				System.out.println("enter you password.. ");
				pwd=sc.next();
				
				if(ser.valpwd(pwd)==false)
					System.err.println( "enter the correct password..");
				}while(ser.valpwd(pwd)==false);
			
			if(ser.chk(accnum ,pwd))
			{
			System.out.println("your balance is"+ser.showBal(accnum));
			System.out.println("enter the deposit amount..");
			double amt=sc.nextDouble();
			System.out.println("your balance is"+ser.deposit(accnum,amt)+"\ndeposited successfully ...");
			}
			else
			System.out.println(" password you hav typied is not matched with the account number");
			break;
			
		case 5:
			
			do{
				System.out.println("enter your account number");
				 accnum=sc.nextLong();
				
				if(ser.valac(accnum)==false)
					System.err.println( "enter the correct account number \n");
				}while(ser.valac(accnum)==false);
				
				do{
				System.out.println("enter you password..\n ");
				pwd=sc.next();
				
				if(ser.valpwd(pwd)==false)
					System.err.println( "enter the correct password..\n");
				}while(ser.valpwd(pwd)==false);
				
			do{
			if(ser.chk(accnum ,pwd))
				
			{long tnum;
			System.out.println("your balance is \n"+ser.showBal(accnum));
			System.out.println("enter the account number you  wish to transfer..\n");
			 tnum=sc.nextLong();
			 do{
			if(ser.chkacc(tnum))
				
			{
				do{
			if(ser.valac(tnum))
				
			{
			System.out.println("enter the amount you need to transfer..\n");
			double amt=sc.nextDouble();
			if(ser.minBal(accnum))
				
			{
				do{
			if(accnum<(ser.showBal(accnum)-1500))
				
			{
				 System.out.println("transfered sucessfully ...\n"
				 		+ "your balance is \t "+ ser.fundTrans(accnum, amt, tnum));
				/*System.out.println(" your balance is"+ser.withdraw(amnt)+"\n withdrawn successfully ...");
				System.out.println(ser.deposit(tnum)+"transaction completed suceesfully..");
				System.out.println("your balance is"+ser.showBal(accnum));*/
			}
			else 
				System.out.println("exicted your minimam balance value...\nplease enter the ammount within the range..");
				
			}while((accnum<(ser.showBal(accnum)-1500))==false);
			}
			else 
				System.out.println("your balance is low..");
			}
			
			else
				System.out.println("you enter the wrong account number...\n"
						+ " please check the account number you hav typied....\n");
			}while((ser.valac(tnum))==false);
			
			}
			else
				System.out.println("the entered account number is not in date base..."
						+ " please enter the correct account number...");
			}while(ser.chkacc(tnum)==false);
			
			}
			
			else
				System.out.println(" password you hav typied is not matched with the account number");
			}while(ser.chk(accnum ,pwd)==false);
			
	
		
		break;
		
		case 6:
			
			do{
				System.out.println("enter your account number");
				 accnum=sc.nextLong();
				
				if(ser.valac(accnum)==false)
					System.err.println( "enter the correct account number");
				}while(ser.valac(accnum)==false);
				
				do{
				System.out.println("enter you password.. ");
				pwd=sc.next();
				
				if(ser.valpwd(pwd)==false)
					System.err.println( "enter the correct password..");
				}while(ser.valpwd(pwd)==false);
			
				
				if(ser.chk(accnum ,pwd))
				{
					
				}
				else 
					System.out.println(" password you hav typied is not matched with the account number");
					
	
			break;
		case 7:
			System.out.println("thanks for using our sevice...");
		default:
			sc.close();
			break;
			}
		
	}
	}
}
		
		
		
		
		
		
		
		
	
		
		
	