package Ser;

import Bank.Customer;
import Dao.ImpDao;

public class ImpSer {
	Customer c=new Customer();
	ImpDao dao= new ImpDao();	
	public long addCustomer(Customer c)
	{
		
		return dao.addCustomer(c);
	}
	public double showBal(long accnum)
	{
		return dao.showBal(accnum);
	}
	
	
	public double withdraw(long accnum,double amt)
	{  
		double g=dao.showBal(accnum)-amt;
		return dao.withdraw(g);
	 
		
	}
	public double deposit(long accnum,double amt)
	{ double g=dao.showBal(accnum)+amt;
	 return  dao.deposit(g);
	
		
	}
	public double fundTrans(long accnum,double amt,long tnum)
	{
		
		return dao.fundTrans(accnum,amt,tnum);
	}
	public String printTrans(long accnum)
	{
		return dao.printTrans(accnum);
	}
	
	
	
	public boolean name(String cname)
	{
		boolean f=false;
		if (cname.matches("^[a-zA-Z\\s]+"))
			f=true;
		return f;
	}
	
	
	
	public boolean pan(String pan_num) {
		// TODO Auto-generated method stub
		
		boolean f=false;
		if (pan_num.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}") )
			f=true;
		
		return f;
	}
	
	
	public boolean dob(String dob) {
		// TODO Auto-generated method stub
		boolean f= false;
		
		if (dob.matches("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$"))
		f=true;
		return f;
	}
	
	
	public boolean phnum(String phnum) {
		// TODO Auto-generated method stub
		boolean f=false;
		if (phnum.matches("[6-9]{1}[0-9]{9}"))
			f=true;
		return f;
	}
	
	public boolean adhar(String adhar) {
		// TODO Auto-generated method stub
		boolean f=false;
		if (adhar.matches("[0-9]{12}"))
			f=true;
		return f;
	}

	public boolean valac(long  accnum)																																														
	{
		
		boolean f=false;
		String s=Long.toString(accnum);
		if(s.matches("[0-9]{15}"))
		{
			f=true;
		}
		return f;
		
	}
	
	public boolean valpwd(String pwd)
	
	{
		boolean f=false;
	
		if(pwd.matches("[0-9]{4}"))
		{
			f=true;
		}
		return f;
		
		
	}
	
		
	
	public boolean balV(long acnum) {
		// TODO Auto-generated method stub
		boolean f= false;
		if((c.getAccnum() == acnum)&&(c.getBal()>=1500))
		{f=true;}
		return f;
	}
	public boolean minBal(long acnum) {
		// TODO Auto-generated method stub
		boolean f= false;
		if (c.getBal()>1500)
		f=true;
		return f;
	}
	
	
public	boolean chk( long accnum ,String pwd)
{
	
return dao. chk(  accnum , pwd);

}	
public	boolean chkacc( long accnum)
{
	return dao. chkacc(  accnum );	
}

}
