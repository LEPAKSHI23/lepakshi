package Ser;

import Bank.Customer;



public interface ISer {
	public long addCustomer(Customer c);
	public double showBal(long accnum);
	public  double withdraw(double accnum);
	public double deposit(double accnum);
	public boolean fundTrans(long accnum);
	public String printTrans(long accnum);
	

}
