package Dao;

import Bank.Customer;

public interface Idao {
	public long addCustomer(Customer c);
	public double showBal(long accnum);
	public  double withdraw(double amt);
	public double deposit(double amt);
	public boolean fundTrans(long accnum);
	public String printTrans(long accnum);

}
