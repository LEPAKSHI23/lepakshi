package Dao;


import java.util.HashMap;


import java.util.Map;

import Bank.Customer;

public class ImpDao {
	static long accnum=123456789000000l;
	Customer c=new Customer();

	 Map<Long,Customer> map=new HashMap<Long,Customer>();    
	
	 
	public long addCustomer(Customer c)
	{
		
		 accnum=accnum+1;
		  map.put(accnum,c);  
		
		
		return accnum;
		}
		
		  

	public boolean chk(long accnum, String pwd) 
	{
		// TODO Auto-generated method stub
		boolean f= false;
		for (Map.Entry<Long, Customer> it : map.entrySet()) 
		{
			c= map.get(it.getKey());
			if(c.getAccnum()==accnum && c.getPwd().equals(pwd) && f==false)
					f=true;
					
			
		}
		return f;
	}
		
	public double showBal(long accnum)
	{
		        
		 return map.get(accnum).getBal();
	}
	public double withdraw(double amt)
	{
		map.get(accnum).setBal(amt);
		map.get(accnum).setHist("amount of"+amt+"is withdrawn\n");
		map.put(accnum,c );
		return map.get(accnum).getBal();
	}
	public double deposit(double amt)
	{ map.get(accnum).setBal(amt);
	map.put(accnum, c);
	map.get(accnum).setHist("amount of "+amt+"is deposited\n");
	return map.get(accnum).getBal();
		
	}
	public double fundTrans(long accnum,double amt,long tnum)
	{
		double s=map.get(accnum).getBal()-amt;
		map.get(accnum).setBal(s);
		map.get(accnum).setHist("amount of"+amt+"is transfered " );
		map.put(accnum, c);
		
		double d=map.get(tnum).getBal()+amt;
		map.get(tnum).setBal(d);
		map.get(tnum).setHist("amount of"+amt+"is deposited through transaction" );
		map.put(tnum, c);
		return map.get(accnum).getBal();
	
	}
	public boolean chkacc(long accnum) {
		// TODO Auto-generated method stub
		boolean f=false;
		for(Map.Entry<Long, Customer> i:map.entrySet())
		{
			if(i.getValue().getAccnum()==accnum&& f==false)
			{
				f=true;
			}
		}
		
		return f;
	}

	

public String printTrans(long accnum)
{
	
		return map.get(accnum).getHist();
	
}
	

}
