package com.capgemini.BankApplication.Service;

import com.capgemini.BankApplication.Been.Customer;
import com.capgemini.BankApplication.Dao.CustomerDaoImplementation;
import com.capgemini.BankApplication.Exception.BankException;



public class CustomerServiceImplementation implements ICustomerService {
	Customer c=new Customer();
	CustomerDaoImplementation dao= new CustomerDaoImplementation ();	
	@Override
	public long addCustomer(Customer c) throws BankException
	{
		
		return dao.addCustomer(c);
	}
	@Override
	public double showBal(long accnum) throws BankException
	{
		return dao.showBal(accnum);
	}
	@Override
	public double withdraw(long accnum,double amt) throws BankException
	{  
		
		return dao.withdraw(accnum,amt);
	}
	@Override
	public double deposit(long accnum,double amt) throws BankException
	{ 
	 return  dao.deposit( accnum,amt);
	
	}
	@Override
	public double fundTrans(long accnum,double amt,long tnum) throws BankException
	{
		
		return dao.fundTrans(accnum,amt,tnum);
	}
	@Override
	public String printTrans(long accnum) throws BankException
	{
		return dao.printTrans(accnum);
	}
	
	
	
	public boolean name(String cname)
	{
		boolean f=false;
		if (cname.matches("^[a-zA-Z\\s]+"))
			f=true;
		return f;
	}
	
	
	
	public boolean pan(String pan_num) {
		boolean f=false;
		if (pan_num.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}") )
			f=true;
		return f;
	}
	
	
	/*public boolean dob(String dob) {
		boolean f= false;
		if (dob.matches("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$"))
		f=true;
		return f;
	}*/
	
	
	public boolean phnum(String phnum) {
		
		boolean f=false;
		if (phnum.matches("[6-9]{1}[0-9]{9}"))
			f=true;
		return f;
	}
	
	public boolean adhar(String adhar) {
		
		boolean f=false;
		if (adhar.matches("[0-9]{12}"))
			f=true;
		return f;
	}

	public boolean valac(long  accnum)																																														
	{
		
		boolean f=false;
		String s=Long.toString(accnum);
		if(s.matches("[0-9]{15}"))
		{
			f=true;
		}
		return f;
		
	}
	
	public boolean valpwd(String pwd)
	
	{
		boolean f=false;
	
		if(pwd.matches("[0-9]{4}"))
		{
			f=true;
		}
		return f;
		
		
	}
	
		
	
	public boolean balV(long acnum) {
	
		
		return dao.balV(acnum);
	}
	public boolean minBal(long acnum) {
		
		
		return dao.minBal(acnum);
	}
	
	
public	boolean chk( long accnum ,String pwd)
{
	
return dao. chk(  accnum , pwd);

}	
public	boolean chkacc( long accnum)
{
	return dao. chkacc(  accnum );	
}

}
