package com.capgemini.BankApplication.Dao;

import com.capgemini.BankApplication.Been.Customer;
import com.capgemini.BankApplication.Exception.BankException;

public interface ICustomerDao {
	public long addCustomer(Customer c) throws BankException;

	public double showBal(long accnum) throws BankException;

	public String printTrans(long accnum) throws BankException;

	public double withdraw(long accnum, double amt) throws BankException;

	public double deposit(long accnum, double amt) throws BankException;

	public double fundTrans(long accnum, double amt, long tnum) throws BankException;

}
